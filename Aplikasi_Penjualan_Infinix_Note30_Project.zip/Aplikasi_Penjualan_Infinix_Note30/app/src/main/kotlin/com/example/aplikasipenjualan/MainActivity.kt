package com.example.aplikasipenjualan

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private val rupiah = NumberFormat.getCurrencyInstance(Locale("id","ID"))
    private lateinit var toko: EditText
    private lateinit var produk: EditText
    private lateinit var qty: EditText
    private lateinit var harga: EditText
    private lateinit var diskon: EditText
    private lateinit var hasil: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }
        scroll.addView(box)

        val title = TextView(this).apply {
            text = "APLIKASI PENJUALAN"
            textSize = 25f
            setTextColor(Color.rgb(21,101,192))
            setTypeface(null, 1)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 28)
        }
        box.addView(title)

        toko = field(box, "Nama Toko")
        produk = field(box, "Nama Produk")
        qty = field(box, "Qty", "1")
        harga = field(box, "Harga Satuan", "0")
        diskon = field(box, "Diskon (%)", "0")

        val hitung = Button(this).apply {
            text = "HITUNG TOTAL"
            setOnClickListener { calculate() }
        }
        box.addView(hitung)

        hasil = TextView(this).apply {
            textSize = 19f
            setPadding(0, 30, 0, 0)
        }
        box.addView(hasil)

        val reset = Button(this).apply {
            text = "RESET"
            setOnClickListener {
                qty.setText("1"); harga.setText("0"); diskon.setText("0")
                hasil.text = ""
            }
        }
        box.addView(reset)

        val info = TextView(this).apply {
            text = "\nVersi 1.0\nData belum tersimpan ke server. Cocok untuk uji coba input order di HP."
            textSize = 14f
            setTextColor(Color.DKGRAY)
        }
        box.addView(info)

        setContentView(scroll)
    }

    private fun field(parent: LinearLayout, hint: String, value: String = ""): EditText {
        val e = EditText(this).apply {
            this.hint = hint
            setText(value)
            textSize = 17f
            inputType = if (hint.contains("Qty") || hint.contains("Harga") || hint.contains("Diskon"))
                android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            else android.text.InputType.TYPE_CLASS_TEXT
        }
        parent.addView(e, LinearLayout.LayoutParams(-1, -2))
        return e
    }

    private fun calculate() {
        val q = qty.text.toString().toDoubleOrNull() ?: 0.0
        val h = harga.text.toString().toDoubleOrNull() ?: 0.0
        val d = diskon.text.toString().toDoubleOrNull() ?: 0.0
        val subtotal = q * h
        val potongan = subtotal * d / 100.0
        val total = subtotal - potongan
        hasil.text = "TOKO: ${toko.text}\nPRODUK: ${produk.text}\n\n" +
                "Subtotal: ${rupiah.format(subtotal)}\n" +
                "Diskon: ${rupiah.format(potongan)}\n" +
                "TOTAL: ${rupiah.format(total)}"
    }
}
